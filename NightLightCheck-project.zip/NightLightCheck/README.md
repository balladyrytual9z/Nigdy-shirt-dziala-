# Night Light Check (Android 9 / API 28)

Minimalna aplikacja diagnostyczna dla radia ESSGOO. Sprawdza, czy firmware udostępnia standardowy ekran ustawień Android Night Light i pozwala spróbować go otworzyć.

## Ważne ograniczenie

Aplikacja nie nakłada filtra i nie może wymusić natywnego Night Light, jeśli producent wyłączył tę funkcję w firmware. AOSP wskazuje, że dostępność zależy m.in. od `config_nightDisplayAvailable` i obsługi transformacji kolorów przez HWC.

## Budowanie APK bez komputera

1. Utwórz nowe repozytorium GitHub.
2. Wgraj wszystkie pliki z tego projektu, zachowując strukturę katalogów.
3. Otwórz zakładkę **Actions** i wybierz **Build Night Light Check APK**.
4. Naciśnij **Run workflow** (albo poczekaj na automatyczny build po dodaniu plików).
5. Po zakończeniu pobierz artefakt `NightLightCheck-APK`. W środku będzie `app-debug.apk`.
6. Przenieś APK na radio i zainstaluj.

Minimalna wersja Androida: 9 (API 28). Architektura CPU nie jest ograniczona, bo aplikacja nie zawiera kodu natywnego.
