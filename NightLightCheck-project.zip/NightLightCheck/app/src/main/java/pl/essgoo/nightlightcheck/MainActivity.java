package pl.essgoo.nightlightcheck;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private TextView details;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        inspect();
    }

    private void buildUi() {
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF3F4F6);

        TextView title = new TextView(this);
        title.setText("Night Light Check");
        title.setTextSize(25);
        title.setTextColor(0xFF111827);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Diagnostyka systemowego filtra barw Androida 9. Aplikacja niczego nie nakłada na ekran i nie zmienia ustawień bez Twojej zgody.");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFF374151);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(10);
        root.addView(subtitle, sp);

        status = new TextView(this);
        status.setTextSize(18);
        status.setTextColor(0xFF111827);
        status.setTypeface(null, 1);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = dp(24);
        root.addView(status, stp);

        details = new TextView(this);
        details.setTextSize(15);
        details.setTextColor(0xFF374151);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = dp(10);
        root.addView(details, dp);

        Button settings = new Button(this);
        settings.setText("Otwórz systemowe ustawienia Night Light");
        settings.setOnClickListener(v -> openNightSettings());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(22);
        root.addView(settings, bp);

        Button refresh = new Button(this);
        refresh.setText("Sprawdź ponownie");
        refresh.setOnClickListener(v -> inspect());
        root.addView(refresh, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("Ważne: wykrycie ekranu ustawień nie dowodzi, że filtr jest obsługiwany sprzętowo. Jeśli producent wyłączył Night Light w firmware, zwykła aplikacja nie może go aktywować natywnie bez uprawnień systemowych/roota lub zmiany firmware.");
        note.setTextSize(13);
        note.setTextColor(0xFF6B7280);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(22);
        root.addView(note, np);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void inspect() {
        Intent intent = new Intent("android.settings.NIGHT_DISPLAY_SETTINGS");
        boolean resolvable = intent.resolveActivity(getPackageManager()) != null;
        if (resolvable) {
            status.setText("Wynik: systemowe ustawienia Night Light są dostępne");
            details.setText("Firmware udostępnia ekran ustawień Night Light. Naciśnij przycisk, aby go otworzyć. Jeśli ekran się otworzy, sprawdź, czy jest tam przełącznik i suwak temperatury.");
        } else {
            status.setText("Wynik: brak standardowego ekranu Night Light");
            details.setText("Nie znaleziono aktywności obsługującej android.settings.NIGHT_DISPLAY_SETTINGS. Producent mógł ukryć lub usunąć tę funkcję. Ten test nie może potwierdzić, czy sama usługa istnieje wewnątrz systemu.");
        }
    }

    private void openNightSettings() {
        Intent intent = new Intent("android.settings.NIGHT_DISPLAY_SETTINGS");
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            status.setText("Nie można otworzyć ustawień Night Light");
            details.setText("Ten firmware nie udostępnia standardowego ekranu ustawień. Aplikacja nie może sama włączyć natywnej korekcji kolorów.");
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
